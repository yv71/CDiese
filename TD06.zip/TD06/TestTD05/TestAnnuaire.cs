﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using TD05;

namespace TestTD05
{
    [TestClass]
    public class TestAnnuaire
    {
        private Annuaire Init()
        {
            Annuaire a = new Annuaire();
            a.Ajouter(new Personne() { Nom = "Dickinson", Prénom = "Bruce", Genre = Genre.MALE });
            a.Ajouter(new Personne() { Nom = "Jansen", Prénom = "Floor", Genre = Genre.FEMELLE });
            return a;
        }

        [TestMethod]
        public void TestLister()
        {
            Annuaire a = Init();
            Personne[] liste = a.Lister();
            Assert.AreEqual(liste.Length , 2);
            Assert.AreEqual(liste[0].Nom, "Dickinson");
            Assert.AreEqual(liste[1].Nom, "Jansen");
        }

        [TestMethod]
        public void TestAjouter()
        {
            Annuaire a = new Annuaire();
            Personne test = new Personne() { Nom = "Harris", Prénom = "Steve", Genre = Genre.MALE };
            a.Ajouter(test);
            Personne[] liste = a.Lister();
            Assert.AreEqual(liste.Length, 1);
            Assert.AreSame(liste[0], test);
        }

        [TestMethod]
        public void TestRetirer()
        {
            Annuaire a = Init();
            Personne test = new Personne() { Nom = "Harris", Prénom = "Steve", Genre = Genre.MALE };
            a.Ajouter(test);
            a.Ajouter(new Personne() { Nom = "Toto" });
            a.Retirer(test);
            Personne[] liste = a.Lister();
            Assert.AreEqual(liste.Length, 3);
            foreach(Personne p in liste)
            {
                Assert.AreNotEqual(p.Nom, "Harris");
                Assert.AreNotSame(p, test);
            }
        }
    }
}
