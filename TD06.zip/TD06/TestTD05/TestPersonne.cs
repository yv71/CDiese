﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using TD05;

namespace TestTD05
{
    [TestClass]
    public class TestPersonne
    {
        [TestMethod]
        public void TestClone()
        {
            Personne p = new Personne()
            {
                Nom = "Dickinson",
                Prénom = "Bruce",
                Adresse = "22 acacia avenue",
                Téléphone = "666 666 666",
                Genre = Genre.MALE,
                Email = "bruce@maiden.com"
            };
            Personne clone = p.Clone() as Personne;
            Assert.IsNotNull(clone);
            Assert.AreEqual(p.Nom, clone.Nom);
            Assert.AreEqual(p.Prénom, clone.Prénom);
            Assert.AreEqual(p.Adresse, clone.Adresse);
            Assert.AreEqual(p.Téléphone, clone.Téléphone);
            Assert.AreEqual(p.Email, clone.Email);
        }
    }
}
