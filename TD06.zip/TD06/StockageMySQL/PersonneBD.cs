﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TD05;

namespace StockageMySQL
{
    /// <summary>
    /// Personne auquelle on rajoute un ID pour le stockage en BDR
    /// </summary>
    class PersonneBD : Personne
    {       
        /// <summary>
        /// Clé primaire (autoinc) de la personne
        /// </summary>
        public int ID { get; set; }

        public override object Clone()
        {
            PersonneBD p = new PersonneBD();
            p.Copier(this);
            return p;
        }

        override public void Copier(IPersonne p)
        {
            base.Copier(p);                        
            if(p is PersonneBD pbd)
            {
                ID = pbd.ID;
            }
        }
    }
}
