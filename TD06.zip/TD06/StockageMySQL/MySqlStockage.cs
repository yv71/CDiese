﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TD05;

namespace StockageMySQL
{
    public class MySqlStockage : IStockage
    {
        private DbConnection con;

        public MySqlStockage()
        {
            con = new MySqlConnection("server=srv-iq-etu;uid=iq2;pwd=iq2;database=annuaire");
            con.Open();
            var com = con.CreateCommand();
            com.CommandText = "SET AUTOCOMMIT=0";
            com.ExecuteNonQuery();
            con.Close();
        }

        public Annuaire Charger()
        {            
            con.Open(); // ouvre la connexion
            // charge toutes les personnes
            DbCommand com = con.CreateCommand();
            com.CommandText = "SELECT * FROM PERSONNE;";
            DbDataReader reader = com.ExecuteReader();
            Annuaire a = new Annuaire();
            // lit la source de données
            while (reader.Read())
            {
                Personne p = new PersonneBD() // crée une nouvelle personne avec les champs issus de la BD
                {
                    Nom = reader["NOM"].ToString(),
                    Prénom = reader["PRENOM"].ToString(),
                    Téléphone = reader["TELEPHONE"].ToString(),
                    Email = reader["EMAIL"].ToString(),
                    Adresse = reader["ADRESSE"].ToString(),
                    ID = Convert.ToInt32(reader["ID"])
                };
                // cas particulier du champ "Genre"
                string temp = reader["GENRE"].ToString();
                if (temp == "M")
                    p.Genre = Genre.MALE;
                else if (temp == "F")
                    p.Genre = Genre.FEMELLE;
                else p.Genre = Genre.NEUTRE;
                a.Ajouter(p); // ajoute dans l'annuaire
            }
            reader.Close(); // ferme avant de ressortir...
            con.Close();
            return a;
        }

        public Personne Créer()
        {
            PersonneBD p = new PersonneBD();
            con.Open();
            DbTransaction trans = con.BeginTransaction();
            try
            {
                // crée une personne dans la base
                var com = con.CreateCommand();
                com.CommandText = "INSERT INTO PERSONNE(NOM,GENRE) VALUES('?','N');";
                com.ExecuteNonQuery();

                // détermine le dernier ID saisi
                com.CommandText = "SELECT LAST_INSERT_ID()";
                var reader = com.ExecuteReader();
                reader.Read();
                int id = Convert.ToInt32(reader[0]);
                reader.Close();
                p.ID = id; // prend l'id lu                 
                trans.Commit();
            }
            catch(Exception x)  // erreur : on annule la transaction et on propage
            {
                trans.Rollback();
                throw x;
            }
            finally // dans tous les cas on ferme la connexion
            {
                con.Close();
            }
            
            return p;
        }

        public void Modifier(Personne p)
        {
            if(p is PersonneBD pbd)
            {
                con.Open(); // ouvre la connexion
                var trans = con.BeginTransaction();
                try
                {                    
                    var com = con.CreateCommand();
                    com.CommandText = "UPDATE PERSONNE SET NOM=@nom, PRENOM=@prenom, EMAIL=@email, TELEPHONE=@telephone, ADRESSE=@adresse, GENRE=@genre WHERE ID=@id";
                    
                    var param = com.CreateParameter();
                    param.ParameterName = "@nom";
                    param.Value = pbd.Nom;
                    com.Parameters.Add(param);

                    param = com.CreateParameter();
                    param.ParameterName = "@prenom";
                    param.Value = pbd.Prénom;
                    com.Parameters.Add(param);

                    param = com.CreateParameter();
                    param.ParameterName = "@email";
                    param.Value = pbd.Email;
                    com.Parameters.Add(param);

                    param = com.CreateParameter();
                    param.ParameterName = "@telephone";
                    param.Value = pbd.Téléphone;
                    com.Parameters.Add(param);

                    param = com.CreateParameter();
                    param.ParameterName = "@adresse";
                    param.Value = pbd.Adresse;
                    com.Parameters.Add(param);

                    param = com.CreateParameter();
                    param.ParameterName = "@id";
                    param.Value = pbd.ID;
                    com.Parameters.Add(param);

                    param = com.CreateParameter();
                    param.ParameterName = "@genre";
                    if (pbd.Genre == Genre.MALE)
                        param.Value = 'M';
                    else if (pbd.Genre == Genre.FEMELLE)
                        param.Value = 'F';
                    else
                        param.Value = 'N';
                    com.Parameters.Add(param);

                    com.ExecuteNonQuery(); // exécute la commande SQL.
                    trans.Commit(); // valide la transaction
                }
                catch(Exception x)
                {
                    trans.Rollback();
                    throw x;
                }
                finally
                {
                    con.Close();
                }
            }
        }

        public void Supprimer(Personne p)
        {
            if (p is PersonneBD pbd)
            {
                con.Open(); // ouvre la connexion
                var trans = con.BeginTransaction();
                try
                {
                    var com = con.CreateCommand();
                    com.CommandText = "DELETE FROM PERSONNE WHERE ID=@id";
                    var param = com.CreateParameter();
                    param.ParameterName = "@id";
                    param.Value = pbd.ID;
                    com.Parameters.Add(param);
                    com.ExecuteNonQuery();
                    trans.Commit();
                }
                catch
                {
                    trans.Rollback();
                    throw;
                }
                finally
                {
                    con.Close();
                }
            }
        }
    }
}
