﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using TD05;
using System.Runtime.Serialization.Json;

namespace StockeSerial
{
    public class StockageJson : IStockage
    {
        private string fichier;
        private Annuaire annuaire;

        public StockageJson(string fichier)
        {
            this.fichier = fichier;
        }
        public Annuaire Charger()
        {
            try
            {
                using (FileStream flux = new FileStream(fichier, FileMode.Open))
                {
                    DataContractJsonSerializer ser = new DataContractJsonSerializer(typeof(Annuaire));
                    annuaire = ser.ReadObject(flux) as Annuaire;
                }
            }
            catch
            {
                annuaire = new Annuaire();
            }
            return annuaire;
        }

        private void Sauver()
        {
            using (FileStream flux = new FileStream(fichier, FileMode.Create))
            {
                DataContractJsonSerializer ser = new DataContractJsonSerializer(typeof(Annuaire));
                ser.WriteObject(flux, annuaire);
            }
        }

        public Personne Créer()
        {
            return new Personne();
        }

        public void Modifier(Personne p)
        {
            Sauver();
        }

        public void Supprimer(Personne p)
        {
            Sauver();
        }
    }
}
