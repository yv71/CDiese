﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace TD05
{
    /// <summary>
    /// Logique d'interaction pour EditePersonne.xaml
    /// </summary>
    public partial class EditePersonne : Window, TD05_métier.Vue
    {
        private Controleur c;
        private PersonneIHM data;
        public EditePersonne(Personne p, Controleur c)
        {
            InitializeComponent();
            this.c = c;
            c.Inscrire(this);
            this.data = new PersonneIHM(p);
            Afficher();
        }

        private void Valider(object sender, RoutedEventArgs e)
        {
            DialogResult = true;
        }

        private void Annuler(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
        }

        public void Creation(Personne p)
        {
            //rien lol
        }

        public void Modification(Personne p)
        {
            if (p.Equals(this.data.Objet))
            {
                Afficher();
            }
        }

        public void Suppression(Personne p)
        {
            if (p.Equals(this.data.Objet))
            {
                DialogResult = false;
            }
        }

        protected override void OnClosed(EventArgs e)
        {
            c.Resilier(this);
        }

        private void Afficher()
        {
            nom.Text = data.Nom;
            prenom.Text = data.Prénom;
            adresse.Text = data.Adresse;
            email.Text = data.Email;
            telephone.Text = data.Téléphone;
            icone.Source = data.Icone;
            masculin.IsChecked = data.Masculin;
            feminin.IsChecked = data.Feminin;
        }
        
        private void nom_LostFocus(object sender, RoutedEventArgs e)
        {
            c.ModifierNom(data.Objet, nom.Text);
        }

        private void prenom_LostFocus(object sender, RoutedEventArgs e)
        {
            c.ModifierPrenom(data.Objet, prenom.Text);
        }

        private void adresse_LostFocus(object sender, RoutedEventArgs e)
        {
            c.ModifierAdresse(data.Objet, adresse.Text);
        }

        private void telephone_LostFocus(object sender, RoutedEventArgs e)
        {
            c.ModifierTelephone(data.Objet, telephone.Text);
        }

        private void email_LostFocus(object sender, RoutedEventArgs e)
        {
            c.ModifierMail(data.Objet, email.Text);
        }

        private void masculin_Checked(object sender, RoutedEventArgs e)
        {
            c.ModifierGenre(data.Objet, Genre.MALE);
        }

        private void feminin_chcked(object sender, RoutedEventArgs e)
        {
            c.ModifierGenre(data.Objet, Genre.FEMELLE);
        }
    }
}
