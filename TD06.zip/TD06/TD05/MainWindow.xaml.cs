﻿using StockageMySQL;
using StockeSerial;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace TD05
{
    /// <summary>
    /// Logique d'interaction pour MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window, TD05_métier.Vue
    {
        private Annuaire a ;
        private Controleur c;
        private IStockage stockage;

        public MainWindow()
        {
            InitializeComponent();
            stockage = new MySqlStockage(); //new StockageJson("test.json");
            a = stockage.Charger();
            c = new Controleur(a);
            c.Inscrire(this);
        }

        private void AfficherListe()
        {
            contacts.Items.Clear();
            foreach(Personne p in a.Lister())
            {
                contacts.Items.Add(new PersonneIHM(p));
            }
        }
        private void ImageLighter(object sender, MouseEventArgs e)
        {
            if(sender is Image img)
            {
                img.Opacity = 0.7;
            }
        }

        private void ImageNormal(object sender, MouseEventArgs e)
        {
            if (sender is Image img)
            {
                img.Opacity = 1;
                
            }
            
        }

        private void Ajouter(object sender, MouseButtonEventArgs e)
        {
            // ajoute une personne
            Personne p = stockage.Créer();           
            EditePersonne dialog = new EditePersonne(p,c);
            if(dialog.ShowDialog()==true)
            {
                a.Ajouter(p);
                AfficherListe();
                stockage.Modifier(p);
            }
        }

        private void Retirer(object sender, MouseButtonEventArgs e)
        {
            // retire une personne
            if(contacts.SelectedItem is PersonneIHM p)
            {
                c.Retirer(p.Objet);
                stockage.Supprimer(p.Objet);
            }
        }

        private void Editer(object sender, MouseButtonEventArgs e)
        {
            // modifie la personne
            if(contacts.SelectedItem is PersonneIHM p)
            {
                EditePersonne dialog = new EditePersonne(p.Objet,c);
                if(dialog.ShowDialog()==true)
                {                    
                    stockage.Modifier(p.Objet);
                }
            }
        }

        public void Creation(Personne p)
        {
            
            contacts.Items.Add(new PersonneIHM(p));
        }

        public void Modification(Personne p)
        {
            contacts.Items.Refresh();
        }

        public void Suppression(Personne p)
        {
            PersonneIHM asuppr = null;
            foreach (PersonneIHM pd in contacts.Items)
            {
                if (pd.Objet.Equals(p))
                {
                    asuppr = pd;
                }
            }  
            
            if (asuppr != null)
            {
                contacts.Items.Remove(asuppr);

            }
        }


    }
}
