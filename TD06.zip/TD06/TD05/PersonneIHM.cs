﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;
using System.Windows.Media.Imaging;

namespace TD05
{
    class PersonneIHM : IPersonne
    {
        private Personne personne;
        public PersonneIHM(Personne p)
        {
            personne = p;
        }

        public string Adresse { get => personne.Adresse; set => personne.Adresse = value; }
        public string Email { get => personne.Email; set => personne.Email = value; }
        public Genre Genre { get => personne.Genre; set => personne.Genre = value; }
        public string Nom { get => personne.Nom; set => personne.Nom = value; }
        public string Prénom { get => personne.Prénom; set => personne.Prénom = value; }
        public string Téléphone { get => personne.Téléphone; set => personne.Téléphone = value; }

        public object Clone()
        {
            return personne.Clone();
        }

        public void Copier(IPersonne p)
        {
            personne.Copier(p);
        }

        public BitmapImage Icone
        {
            get
            {
                string url = "pack://application:,,,/TD05;component/Images/";
                switch(Genre)
                {
                    case Genre.FEMELLE:
                        url += "contact_f.png";
                        break;
                    case Genre.MALE:
                        url += "contact_m.png";
                        break;
                    default:
                        url += "contact_x.png";
                        break;
                }
                return new BitmapImage(new Uri(url));
            }
        }

        public Personne Objet { get => personne; }

        public bool Masculin
        {
            get { return Genre == Genre.MALE; }
            set {if (value) Genre = Genre.MALE; }
        }
        public bool Feminin
        {
            get { return Genre == Genre.FEMELLE; }
            set { if (value) Genre = Genre.FEMELLE; }
        }
    }
}
