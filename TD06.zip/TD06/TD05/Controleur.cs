﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TD05_métier;

namespace TD05
{
    public class Controleur
    {
        private Annuaire a;
        private List<Vue> view;

        public Controleur(Annuaire a)
        {
            this.a = a;
            view = new List<Vue>();
        }

        public void Inscrire (Vue v)
        {
            view.Add(v);
        }

        public void Resilier(Vue v)
        {
            if (view.Contains(v))
            {
                view.Remove(v);
            }
        }

        protected void NotifieCreation(Personne p)
        {
            foreach(Vue v in view)
            {
                v.Creation(p);
            }
        }

        protected void NotifieModification(Personne p)
        {
            foreach (Vue v in view)
            {
                v.Modification(p);
            }
        }

        protected void NotifieSuppression(Personne p)
        {
            foreach (Vue v in view)
            {
                v.Suppression(p);
            }
        }
        public void Ajouter(Personne p)
        {
            a.Ajouter(p);
            this.NotifieCreation(p);
        }

        public void Retirer(Personne p)
        {
            a.Retirer(p) ;
            this.NotifieSuppression(p);
        }

        public void ModifierNom(Personne p, String nom)
        {
            foreach(Personne pd in a.Lister())
            {
                if (pd.Equals(p))
                {
                    pd.Nom = nom;
                    this.NotifieModification(pd);
                }
            }
        }

        public void ModifierAdresse(Personne p, String adresse)
        {
            foreach (Personne pd in a.Lister())
            {
                if (pd.Equals(p))
                {
                    pd.Adresse = adresse;
                    this.NotifieModification(pd);
                }
            }
        }

        public void ModifierPrenom(Personne p, String prenom)
        {
            foreach (Personne pd in a.Lister())
            {
                if (pd.Equals(p))
                {
                    pd.Prénom = prenom;
                    this.NotifieModification(pd);
                }
            }
        }

        public void ModifierMail(Personne p, String mail)
        {
            foreach (Personne pd in a.Lister())
            {
                if (pd.Equals(p))
                {
                    pd.Email = mail;
                    this.NotifieModification(pd);
                }
            }
        }

        public void ModifierGenre(Personne p, Genre genre)
        {
            foreach (Personne pd in a.Lister())
            {
                if (pd.Equals(p))
                {
                    pd.Genre = genre;
                    this.NotifieModification(pd);
                }
            }
        }

        public void ModifierTelephone(Personne p, String telephone)
        {
            foreach (Personne pd in a.Lister())
            {
                if (pd.Equals(p))
                {
                    pd.Téléphone = telephone;
                    this.NotifieModification(pd);
                }
            }
        }
    }
}
