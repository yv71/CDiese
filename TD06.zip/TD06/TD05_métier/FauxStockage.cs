﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TD05
{
    public class FauxStockage : IStockage
    {
        public Annuaire Charger()
        {
            Annuaire a = new Annuaire();
            a.Ajouter(new Personne() { Nom = "Dickinson", Prénom = "Bruce", Genre = Genre.MALE });
            a.Ajouter(new Personne() { Nom = "Jansen", Prénom = "Floor", Genre = Genre.FEMELLE });
            return a;
        }

        public Personne Créer()
        {
            return new Personne();
        }

        public void Modifier(Personne p)
        {
            
        }

        public void Supprimer(Personne p)
        {
            
        }
    }
}
