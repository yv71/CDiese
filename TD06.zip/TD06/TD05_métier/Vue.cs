﻿using System;
using System.Collections.Generic;
using System.Text;
using TD05;
using TD05_métier;

namespace TD05_métier
{
    public interface Vue
    {
        void Creation(Personne p);

        void Modification(Personne p);

        void Suppression(Personne p);
    }
}
