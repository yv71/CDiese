﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace TD05
{
    [DataContract]
    public enum Genre { NEUTRE, MALE, FEMELLE };

    /// <summary>
    /// Représente une personne
    /// </summary>
    [DataContract]
    public class Personne : ICloneable, IPersonne
    {
        [DataMember]
        private string nom;
        [DataMember]
        private string prénom;
        [DataMember]
        private string téléphone;
        [DataMember]
        private string email;
        [DataMember]
        private string adresse;
        [DataMember]
        private Genre genre;

        /// <summary>
        /// Fixe ou obtient le nom de la personne
        /// </summary>
        public string Nom { get => nom; set => nom = value; }
        /// <summary>
        /// Fixe ou obtient le prénom de la personne
        /// </summary>
        public string Prénom { get => prénom; set => prénom = value; }
        /// <summary>
        /// Fixe ou obtient le téléphone de la personne
        /// </summary>
        public string Téléphone { get => téléphone; set => téléphone = value; }
        /// <summary>
        /// Fixe ou obtient le mail de la personne
        /// </summary>
        public string Email { get => email; set => email = value; }
        /// <summary>
        /// Fixe ou obtient l'adresse de la personne
        /// </summary>
        public string Adresse { get => adresse; set => adresse = value; }
        /// <summary>
        /// Fixe ou obtient le genre de la personne
        /// </summary>
        public Genre Genre { get => genre; set => genre = value; }

        /// <summary>
        /// Recopie les attributs de la personne paramètre
        /// </summary>
        /// <param name="p">la personne à recopier</param>
        virtual public void Copier(IPersonne p)
        {
            nom = p.Nom;
            prénom = p.Prénom;
            téléphone = p.Téléphone;
            email = p.Email;
            adresse = p.Adresse;
            genre = p.Genre;
        }

        virtual public object Clone()
        {
            Personne p = new Personne();
            p.Copier(this);
            return p;
        }

        
        
    }
}
