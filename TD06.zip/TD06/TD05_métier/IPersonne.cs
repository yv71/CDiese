﻿namespace TD05
{
    public interface IPersonne
    {
        string Adresse { get; set; }
        string Email { get; set; }
        Genre Genre { get; set; }
        string Nom { get; set; }
        string Prénom { get; set; }
        string Téléphone { get; set; }

        object Clone();
        void Copier(IPersonne p);
    }
}