﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TD05
{
    public interface IStockage
    {
        Personne Créer();
        void Modifier(Personne p);
        void Supprimer(Personne p);
        Annuaire Charger();        
    }
}
